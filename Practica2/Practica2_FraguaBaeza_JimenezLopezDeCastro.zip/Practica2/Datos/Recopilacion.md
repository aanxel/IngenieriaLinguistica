# Deportes
1-60 noticias de El Marca
1-20 noticias de Fútbol (19 y 20 fútbol femenino)
21-40 noticias de Baloncesto
41-60 noticias de Atletismo


- text1.txt(238 palabras): Calleja: "Hemos hecho el mejor partido de la temporada" - https://www.marca.com/futbol/alaves/2021/11/27/61a2569022601d70108b4584.html

- text2.txt(479 palabras): El Barça se lanza a por Ferran Torres - https://www.marca.com/futbol/barcelona/2021/11/26/61a11880e2704ece6f8b45de.html

- text3.txt(237 palabras): Simeone ya tiene a Joao Félix a sus órdenes - https://www.marca.com/futbol/atletico/2021/11/27/61a220ad46163ff9588b45b2.html

- text4.txt(386 palabras): El Córdoba, campeón de la Copa Federación - https://www.marca.com/futbol/2021/11/23/619d6a33ca47419e618b456e.html

- text5.txt(169 palabras): La nieve altera los entrenamientos - https://www.marca.com/futbol/valladolid/2021/11/24/619e8a01268e3ea72d8b4573.html

- text6.txt(361 palabras): El infalible Real Madrid - https://www.marca.com/futbol/real-madrid/2021/11/25/619ec4d522601d15488b45b4.html

- text7.txt(337 palabras): Ansu Fati le da vueltas: Bayern sí, Bayern no - https://www.marca.com/futbol/barcelona/2021/11/25/619faab2ca4741f46c8b4586.html

- text8.txt(320 palabras): Thiago Alcántara: "El gol al Oporto es lo más bonito que he hecho" - https://www.marca.com/futbol/champions-league/2021/11/25/619fab4fe2704e6b0a8b45e1.html

- text9.txt(387 palabras): Simeone: "La champions no te perdona y sólo te deja pasar si lo mereces" - https://www.marca.com/futbol/atletico/2021/11/24/619ebafce2704e805e8b45cc.html

- text10.txt(657 palabras): La parábola de Junior Messias: de cargar frigoríficos a 'verdugo' del Atlético - https://www.marca.com/futbol/champions-league/2021/11/25/619f5c57e2704ea0348b45cf.html

- text11.txt(700 palabras): Cuatro españoles en la cuerda floja... y jugándosela a domicilio - https://www.marca.com/futbol/champions-league/2021/11/25/619ece3aca4741227d8b4586.html

- text12.txt(585 palabras): El Barça más seco en la historia de la Champions - https://www.marca.com/futbol/barcelona/2021/11/25/619f6947ca4741cb7c8b4593.html

- text13.txt(526 palabras): Otro acierto con Alaba: también vino para marcar de falta - https://www.marca.com/futbol/real-madrid/2021/11/25/619eaaa046163fd76b8b45cd.html

- text14.txt(207 palabras): El vacile madridista en el Metropolitano de Brahim y Theo Hernández - https://www.marca.com/futbol/champions-league/2021/11/25/619f5b7846163ff03d8b45a4.html

- text15.txt(290 palabras): Un desastre ante su hinchada - https://www.marca.com/futbol/atletico/2021/11/25/619ec910e2704e4b398b45c6.html

- text16.txt(383 palabras): Sin gol es imposible competir - https://www.marca.com/futbol/atletico/2021/11/25/619ecd9fe2704e4b398b45cc.html

- text17.txt(477 palabras): La Champions la ganan los grandes equipos y este PSG no lo es - https://www.marca.com/futbol/champions-league/2021/11/24/619eb6b346163f728c8b45a3.html

- text18.txt(317 palabras): El Madrid: mejor racha de la temporada y doble liderato Liga-Champions - https://www.marca.com/futbol/champions-league/2021/11/24/619eaf8622601d71248b45fc.html

- text19.txt(434 palabras): El campeón ya está en cuartos - https://www.marca.com/futbol/futbol-femenino/champions-league/tsg-hoffenheim-vs-barcelona/cronica/2021/11/17/61953a77268e3eac6e8b457a.html

- text20.txt(349 palabras): Dos errores condenan al Real Madrid ante el PSG - https://www.marca.com/futbol/futbol-femenino/champions-league/r-madrid-vs-paris-saint-germain/cronica/2021/11/18/6196abbae2704ecb828b45f3.html

- text21.txt(339 palabras): Los Lakers sucumben ante los Kings después de tres prórrogas - https://www.marca.com/baloncesto/nba/2021/11/27/61a1e1fbe2704e951f8b45ac.html

- text22.txt(263 palabras): La inaceptable frase que desató la furia de LeBron James: "Ojalá tu hijo muera en un accidente de tráfico" - https://www.marca.com/baloncesto/nba/2021/11/26/61a08037ca4741781d8b4582.html

- text23.txt(232 palabras): El San Pablo Burgos rescinde los contratos de Steve Zack y Suleiman Braimoh - https://www.marca.com/baloncesto/acb/2021/11/27/61a2813d46163f1fb78b4590.html

- text24.txt(272 palabras): ¿Cuánto valían las entradas en el primer partido de la historia de la NBA? Te sorprenderá - https://www.marca.com/baloncesto/nba/2021/11/27/61a20c3c46163f5b5f8b45e8.html

- text25.txt(337 palabras): El Barça aplasta al Zalgiris a golpe de triple - https://www.marca.com/baloncesto/euroliga/2021/11/26/61a158aaca474195088b4592.html

- text26.txt(524 palabras): España inicia su camino al Mundial 2023 triturando a Macedonia (65-94) - https://www.marca.com/baloncesto/mundial/2021/11/26/61a12146e2704e5d898b45d0.html

- text27.txt(561 palabras): Los Spurs invertirán 511 millones en medicina y ciencia deportiva - https://www.marca.com/baloncesto/nba/2021/11/26/61a11550ca474158138b45ed.html

- text28.txt(143 palabras): El Coosur Betis, a punto de cerrar el fichaje del base Aleksandar Cvetkovic - https://www.marca.com/baloncesto/acb/2021/11/26/61a10f26e2704e566e8b457b.html

- text29.txt(229 palabras): Susto de Serbia, derrotas de Grecia, Alemania y Turquía... las sorpresas de las emocionantes Ventanas FIBA - https://www.marca.com/baloncesto/2021/11/26/61a0a2aeca47416a758b45c4.html

- text30.txt(421 palabras): España empieza la defensa de su corona Mundial con un duelo trampa ante Macedonia - https://www.marca.com/baloncesto/seleccion/2021/11/26/61a09b77ca4741781d8b4589.html

- text31.txt(260 palabras): Pablo Laso: "Los grandes jugadores juegan mejor cuando el público les aprieta" - https://www.marca.com/baloncesto/euroliga/2021/11/25/61a00cab46163f854d8b459d.html

- text32.txt(277 palabras): El Burgos toma oxígeno en Alemania en el primer partido sin Zan Tabak - https://www.marca.com/baloncesto/champions-league/2021/11/17/619570c5ca474134348b45a5.html

- text33.txt(625 palabras): El Lenovo Tenerife remonta para llevarse un sufrido triunfo - https://www.marca.com/baloncesto/champions-league/2021/11/10/618bef82e2704e540f8b45ea.html

- text34.txt(331 palabras): El Manresa pone rumbo a los octavos en la Champions - https://www.marca.com/baloncesto/champions-league/2021/11/09/618af3e2e2704e549a8b45ab.html

- text35.txt(288 palabras): Un gran tercer cuarto da al Hereda San Pablo Burgos un triunfo balsámico - https://www.marca.com/baloncesto/champions-league/2021/11/02/6181791c22601d295b8b462d.html

- text36.txt(638 palabras): El mejor Unicaja de la temporada aplasta a un débil Dijon - https://www.marca.com/baloncesto/champions-league/2021/11/01/61805bb5268e3e9f4a8b45e6.html

- text37.txt(373 palabras): Las pérdidas provocan la primera derrota del Lenovo Tenerife - https://www.marca.com/baloncesto/champions-league/2021/10/27/617969aa22601d0d628b457c.html

- text38.txt(338 palabras): El Baxi Manresa asalta Karsiyaka y continúa invicto en la Champions - https://www.marca.com/baloncesto/champions-league/2021/10/26/617854a622601d92318b45a4.html

- text39.txt(626 palabras): El Unicaja supera con solvencia el estreno de la Champions en Málaga - https://www.marca.com/baloncesto/champions-league/2021/10/20/6170850aca4741b82c8b4586.html

- text40.txt(346 palabras): Un mal segundo cuarto condena al Burgos en Lituania - https://www.marca.com/baloncesto/champions-league/2021/10/19/616f186446163fce118b45a2.html

- text41.txt(191 palabras): El cross de Alcobendas, último paso para la confección del equipo del Europeo - https://www.marca.com/atletismo/2021/11/27/61a0e93aca4741cc248b4587.html

- text42.txt(438 palabras): "La prueba de esfuerzo para corredores de más de 45 años debería ser obligatoria" - https://www.marca.com/atletismo/2021/11/26/61a0eee8268e3ed72e8b45b3.html

- text43.txt(175 palabras): Orlando Ortega empieza a trabajar en el CAR de Sant Cugat - https://www.marca.com/atletismo/2021/11/24/619e4e2ee2704e330f8b45c8.html

- text44.txt(545 palabras): Haile Gebrselassie, dispuesto a ir al frente de la guerra de Tigray - https://www.marca.com/atletismo/2021/11/24/619e4002ca4741f0698b45ce.html

- text45.txt(222 palabras): Hassan, Kipyegon, McLaughlin, Rojas y Thompson-Herah, finalistas a Atleta del año - https://www.marca.com/atletismo/2021/11/23/619d0c9e46163f932e8b462c.html

- text46.txt(401 palabras): Kipchoge, Duplantis, Cheptegei, Crouser y Warholm, finalistas a Atleta del Año - https://www.marca.com/atletismo/2021/11/22/619bc39dca4741324b8b456c.html

- text47.txt(457 palabras): Eusebio Cáceres: "Mi cuerpo y mi mente pueden ofrecer mucho todavía" - https://www.marca.com/atletismo/2021/11/22/619ba539e2704eb45d8b457c.html

- text48.txt(340 palabras): Rodrigue Kwizera y Tanui Jeruto se llevan los laureles en el cross de Itálica - https://www.marca.com/atletismo/2021/11/21/619a4f93ca4741481d8b45d8.html

- text49.txt(471 palabras): Carla Suárez, sobre su futuro: "Quiero vivir el presente" - https://www.marca.com/atletismo/2021/11/21/619a3a6bca474166708b45c6.html

- text50.txt(199 palabras): Jacob Kiplimo bate el récord del mundo de medio maratón con 57:31 - https://www.marca.com/atletismo/2021/11/21/619a3150ca47417f018b45ae.html

- text51.txt(306 palabras): Marta Pérez, la española más rápida de la historia en correr 5 km con 15:04 - https://www.marca.com/atletismo/2021/11/21/619a2cfeca4741f96a8b45c3.html

- text52.txt(357 palabras): Hamza Zeroual, tras su gesto viral: "Simplemente me puse en su situación, no lo dudé" - https://www.marca.com/atletismo/2021/11/20/6197d4da46163f00808b45de.html

- text53.txt(245 palabras): Playas de Castellón, tricampeón de España de relevo mixto y billete al Europeo - https://www.marca.com/atletismo/2021/11/20/61991d75ca4741a70a8b461b.html

- text54.txt(496 palabras): Las leyendas de la marcha española se reúnen en homenaje a Jordi Llopart - https://www.marca.com/atletismo/2021/11/20/6198f2dbe2704e99b98b457c.html

- text55.txt(350 palabras): Rodrigue Kwizera y Margaret Chelimo buscan los laureles en Itálica - https://www.marca.com/atletismo/2021/11/19/6197884c268e3e783d8b460e.html

- text56.txt(367 palabras): Marta Pérez y Abadía, a por las mejores marcas españolas de 5 y 10 km en Alcobendas - https://www.marca.com/atletismo/2021/11/19/6197aba846163f57228b4632.html

- text57.txt(312 palabras): World Athletics prolonga la exclusión del atletismo ruso - https://www.marca.com/atletismo/2021/11/17/619522fa268e3e274e8b45a0.html

- text58.txt(344 palabras): Pelotazo de la Noche de San Antón de Jaén: cara a cara entre Kiplimo y Katir - https://www.marca.com/atletismo/2021/11/16/6193fa9bca474127748b4631.html

- text59.txt(476 palabras): Schwazer confiesa que iba a Turquía a escondidas para doparse: "Era un adicto" - https://www.marca.com/atletismo/2021/11/16/6193cf5946163f972a8b45d9.html

- text60.txt(591 palabras): El reto que no ocurrió de Bolt: "Yo podría haber ganado el oro en Tokio" - https://www.marca.com/atletismo/2021/11/15/6192562de2704eeba28b4595.html


# Salud
1-30 noticias de El País
31-60 noticias de El Mundo


- text1.txt(592 palabras): Los pacientes por coronavirus aumentan un 35% en la Atención Primaria de Cataluña - https://elpais.com/espana/catalunya/2021-11-24/los-pacientes-por-coronavirus-aumentan-un-35-en-la-atencion-primaria-de-cataluna.html

- text2.txt(557 palabras): Los alergólogos aconsejan vacunar contra la gripe a los niños con asma para evitar complicaciones - https://elpais.com/mamas-papas/expertos/2021-11-24/los-alergologos-aconsejan-vacunar-contra-la-gripe-a-los-ninos-con-asma-para-evitar-complicaciones.html

- text3.txt(485 palabras): Un jurado popular considera a tres grandes cadenas de farmacia responsables de la crisis de opioides en EE UU - https://elpais.com/sociedad/2021-11-23/un-jurado-popular-considera-a-tres-grandes-cadenas-de-farmacia-responsables-de-la-crisis-de-opioides-en-ee-uu.html

- text4.txt(611 palabras): Barcelona señala los comercios de alimentación no saludables - https://elpais.com/espana/catalunya/2021-11-18/barcelona-senala-los-comercios-de-alimentacion-no-saludables.html

- text5.txt(395 palabras): La epidemia de drogas lleva a EE UU a alcanzar un récord de muertos por sobredosis - https://elpais.com/internacional/2021-11-17/la-epidemia-de-drogas-en-ee-uu-es-ya-la-mas-mortifera-jamas-vivida-en-el-pais.html

- text6.txt(719 palabras): México empieza a vacunar contra la covid a todos los menores de 15 a 17 años - https://elpais.com/mexico/2021-11-16/inicia-el-turno-para-vacunar-contra-la-covid-a-todos-los-menores-de-15-a-17-anos.html

- text7.txt(424 palabras): Los positivos aumentan un 52% en Cataluña en una semana - https://elpais.com/espana/catalunya/2021-11-14/los-positivos-aumentan-un-52-en-cataluna-en-una-semana.html

- text8.txt(536 palabras): ¿Qué relación tiene el frío con el catarro y la gripe? - https://elpais.com/ciencia/las-cientificas-responden/2021-11-12/que-relacion-tiene-el-frio-con-el-catarro-y-la-gripe.html

- text9.txt(571 palabras): Úlceras célebres - https://elpais.com/ciencia/el-hacha-de-piedra/2021-11-11/ulceras-celebres.html

- text10.txt(921 palabras): Inteligencia artificial para predecir un ictus con dos años de antelación - https://elpais.com/tecnologia/2021-11-04/inteligencia-artificial-para-predecir-un-ictus-con-dos-anos-de-antelacion.html

- text11.txt(598 palabras): Un médico canadiense inseminó a un centenar de mujeres con esperma no seleccionado por los padres - https://elpais.com/sociedad/2021-11-02/un-medico-canadiense-insemino-a-un-centenar-de-mujeres-con-esperma-no-seleccionado-por-los-padres.html

- text12.txt(676 palabras): México concluye su plan de vacunación: un 83% de la población mayor de edad tiene al menos la primera dosis - https://elpais.com/mexico/2021-10-29/mexico-concluye-su-plan-de-vacunacion-un-83-de-la-poblacion-mayor-de-edad-tiene-al-menos-la-primera-dosis.html

- text13.txt(587 palabras): Ciudad de México concluye la vacunación de los mayores de 18 años - https://elpais.com/mexico/2021-10-28/ciudad-de-mexico-concluye-la-vacunacion-de-los-mayores-de-18-anos.html

- text14.txt(444 palabras): Así puedes pedir cita online en el CAP en Cataluña - https://elpais.com/espana/catalunya/2021-10-28/asi-puedes-pedir-cita-online-en-el-cap-en-cataluna.html

- text15.txt(680 palabras): El óxido de etileno, el compuesto cancerígeno desapercibido en México - https://elpais.com/mexico/2021-10-25/el-oxido-de-etileno-el-compuesto-cancerigeno-desapercibido-en-mexico.html

- text16.txt(481 palabras): EE UU aprueba la dosis de refuerzo de Moderna y Janssen, y respalda la mezcla de vacunas - https://elpais.com/sociedad/2021-10-21/la-agencia-del-medicamento-de-ee-uu-aprueba-la-dosis-de-refuerzo-de-moderna-y-janssen-y-respalda-la-mezcla-de-vacunas.html

- text17.txt(776 palabras): La cebolla de Chihuahua provoca alerta por un brote de salmonela en Estados Unidos - https://elpais.com/mexico/2021-10-21/la-cebolla-de-chihuahua-provoca-alerta-por-un-brote-de-salmonela-en-estados-unidos.html

- text18.txt(433 palabras): EE UU planea autorizar la administración de una marca de vacuna diferente de la inicial en las dosis de refuerzo - https://elpais.com/sociedad/2021-10-19/ee-uu-planea-autorizar-la-administracion-de-una-marca-de-vacuna-diferente-de-la-inicial-en-las-dosis-de-refuerzo.html

- text19.txt(673 palabras): La mortalidad por coronavirus cae al mínimo de la pandemia en Cataluña - https://elpais.com/espana/catalunya/2021-10-15/la-mortalidad-por-coronavirus-cae-al-minimo-de-la-pandemia-en-cataluna.html

- text20.txt(568 palabras): La Ciudad de México pasará este lunes a semáforo verde ante la disminución de contagios - https://elpais.com/mexico/2021-10-15/la-ciudad-de-mexico-pasara-este-lunes-a-semaforo-verde-ante-la-disminucion-de-contagios.html

- text21.txt(596 palabras): Hospitales de Cataluña: una década para crecer - https://elpais.com/espana/catalunya/2021-10-14/hospitales-de-cataluna-una-decada-para-crecer.html

- text22.txt(373 palabras): Los valencianos aún son reticentes a participar en actividades en interiores por el coronavirus - https://elpais.com/espana/comunidad-valenciana/2021-10-02/los-valencianos-aun-son-reticentes-a-participar-en-actividades-en-interiores-por-el-coronavirus.html

- text23.txt(438 palabras): Corre, corre y (de paso) vence al cáncer de pecho - https://elpais.com/planeta-futuro/alterconsumismo/2021-09-24/corre-corre-y-de-paso-vence-al-cancer-de-pecho.html

- text24.txt(630 palabras): La autoridad sanitaria de EE UU recomienda una tercera dosis de la vacuna contra la covid para adultos mayores y enfermos - https://elpais.com/sociedad/2021-09-23/las-autoridades-sanitarias-de-ee-uu-recomiendan-una-tercera-dosis-de-la-vacuna-contra-la-covid-para-adultos-mayores-y-enfermos.html

- text25.txt(527 palabras): La agencia del medicamento de EE UU aprueba la tercera dosis solo para mayores de 65 años y personas en riesgo - https://elpais.com/america/internacional/2021-09-23/la-agencia-del-medicamento-de-ee-uu-aprueba-administrar-la-tercera-dosis-de-la-vacuna-contra-la-covid-a-los-mayores-de-65-anos.html

- text26.txt(499 palabras): Alzhéimer: Un año para recordar - https://elpais.com/espana/catalunya/2021-09-21/alzheimer-un-ano-para-recordar.html

- text27.txt(421 palabras): El PSC culpa a la Generalitat de tener un millón de vacunas en riesgo de caducar - https://elpais.com/espana/catalunya/2021-09-17/el-psc-culpa-a-la-generalitat-de-tener-un-millon-de-vacunas-en-riesgo-de-caducar.html

- text28.txt(589 palabras): La Junta de Extremadura prohíbe a dos hermanas entrar en el colegio sin mascarilla - https://elpais.com/educacion/2021-09-15/la-junta-de-extremadura-prohibe-a-dos-hermanas-entrar-en-el-colegio-sin-mascarilla.html

- text29.txt(484 palabras): Nomura prohíbe fumar a sus empleados incluso cuando teletrabajan - https://elpais.com/economia/2021-09-15/nomura-prohibe-fumar-a-sus-empleados-incluso-cuando-teletrabajan.html

- text30.txt(324 palabras): Cataluña empezará a desmantelar los puntos de vacunación masiva contra la covid - https://elpais.com/espana/catalunya/2021-09-10/cataluna-empezara-a-desmantelar-los-puntos-de-vacunacion-masiva-contra-la-covid.html

- text31.txt(528 palabras): España supera los 200 casos hasta llegar a los 208 tras notificar 10.261 contagios - https://www.elmundo.es/ciencia-y-salud/salud/2021/11/30/61a6469021efa0bb418b45be.html

- text32.txt(255 palabras): Las vacunas para menores no llegarán antes de segunda quincena de diciembre - https://www.elmundo.es/ciencia-y-salud/salud/2021/11/30/61a600a621efa015548b45db.html

- text33.txt(291 palabras): Los relojes inteligentes, a un paso de detectar el Covid-19 - https://www.elmundo.es/ciencia-y-salud/salud/2021/11/30/61a606bd21efa07d118b45b0.html

- text34.txt(324 palabras): Moderna alerta de que las vacunas "podrían ser ineficaces contra la variante ómicron" - https://www.elmundo.es/ciencia-y-salud/salud/2021/11/30/61a5ea1421efa07d118b45a7.html

- text35.txt(290 palabras): Biden: "La variante ómicron es motivo de preocupación, pero no de pánico" - https://www.elmundo.es/ciencia-y-salud/salud/2021/11/29/61a52b9ffdddffc1bd8b459f.html

- text36.txt(301 palabras): Los asesores del Gobierno británico proponen la vacuna de refuerzo para mayores de 18 y a los tres meses de la segunda dosis - https://www.elmundo.es/ciencia-y-salud/salud/2021/11/29/61a516d821efa0dd3f8b45aa.html

- text37.txt(218 palabras): El G7 advierte que la variante ómicron es "altamente transmisible" y requiere "medidas urgentes" - https://www.elmundo.es/ciencia-y-salud/salud/2021/11/29/61a500fc21efa0d92a8b4599.html

- text38.txt(526 palabras): El Hospital Gregorio Marañón confirma el primer caso de la variante ómicron en España - https://www.elmundo.es/ciencia-y-salud/salud/2021/11/29/61a5025f21efa0dd3f8b45a1.html

- text39.txt(558 palabras): Detenida una pareja que se saltó la cuarentena en Ámsterdam para ir a Barcelona - https://www.elmundo.es/ciencia-y-salud/salud/2021/11/29/61a4a8cf21efa0e64d8b457a.html

- text40.txt(484 palabras): La OMS pide a los países prepararse porque la variante ómicron presenta "un riesgo muy elevado" a nivel mundial - https://www.elmundo.es/ciencia-y-salud/salud/2021/11/29/61a496d7fdddff32838b45bd.html

- text41.txt(326 palabras): La primera imagen de la variante ómicron del coronavirus - https://www.elmundo.es/ciencia-y-salud/salud/2021/11/28/61a3c404fc6c8324408b458d.html

- text42.txt(488 palabras): El presidente alemán llama a reducir los contactos para evitar el cierre de la vida pública: "Hagámoslo para salvar vidas" - https://www.elmundo.es/ciencia-y-salud/salud/2021/11/28/61a34c3221efa0d84e8b4592.html

- text43.txt(386 palabras): Reino Unido vuelve a los PCR y cuarentenas a la llegada tras los dos casos de la nueva variante - https://www.elmundo.es/ciencia-y-salud/salud/2021/11/27/61a27077fdddff02ae8b459b.html

- text44.txt(260 palabras): Alerta para los alérgicos al cacahuete por la presencia no declarada de este producto en una barritas de chocolate - https://www.elmundo.es/ciencia-y-salud/salud/2021/11/27/61a26a9ae4d4d8de7b8b45bb.html

- text45.txt(297 palabras): 61 pasajeros procedentes de Sudáfrica dan positivo al coronavirus a su llegada a Holanda - https://www.elmundo.es/ciencia-y-salud/salud/2021/11/27/61a1f94cfdddffc4948b457f.html

- text46.txt(321 palabras): Moderna desarrollará un refuerzo específico de la vacuna contra la nueva variante Ómicron - https://www.elmundo.es/ciencia-y-salud/salud/2021/11/26/61a15a27fdddffe2b08b45e2.html

- text47.txt(350 palabras): Niegan la entrada de un crucero con 300 pasajeros a un puerto argentino por un positivo de la variante Ómicron - https://www.elmundo.es/internacional/2021/12/01/61a72d7bfc6c830f788b45a7.html

- text48.txt(307 palabras): Suiza aprueba en referéndum el pasaporte Covid tras una campaña muy agitada - https://www.elmundo.es/internacional/2021/11/28/61a36ef0fdddff3d3e8b4574.html

- text49.txt(406 palabras): La OMS avisa que Europa afronta un "invierno duro" por el repunte de la pandemia de coronavirus - https://www.elmundo.es/ciencia-y-salud/salud/2021/11/10/618b71d421efa09c1e8b456d.html

- text50.txt(391 palabras): La OMS advierte de que Europa registra la mayor subida de nuevos casos de Covid-19 - https://www.elmundo.es/ciencia-y-salud/salud/2021/10/28/617a5095fdddff442f8b45cc.html

- text51.txt(413 palabras): Uno de los 150 españoles atrapados en Sudáfrica: "Todo el mundo busca vuelos para salir y no hay, es un caos" - https://www.elmundo.es/ciencia-y-salud/salud/2021/11/28/61a3873521efa056018b458b.html

- text52.txt(377 palabras): La variante ómicron del coronavirus en Europa: ya en siete países y pendiente de confirmación en Francia - https://www.elmundo.es/ciencia-y-salud/salud/2021/11/27/61a24a52e4d4d8401a8b45c9.html

- text53.txt(380 palabras): ¿Por qué hay que vacunar a los niños contra el Covid? "La vacuna es segura y tienen derecho a recibirla" - https://www.elmundo.es/ciencia-y-salud/salud/2021/11/30/61a5cbee21efa003278b45be.html

- text54.txt(468 palabras): Los médicos de urgencias, clave para detectar los casos silenciosos de VIH - https://www.elmundo.es/ciencia-y-salud/salud/2021/12/01/61a609bde4d4d800208b4588.html

- text55.txt(430 palabras): La vacuna de Pfizer para menores de 12 años estará disponible en menos de dos semanas - https://www.elmundo.es/ciencia-y-salud/salud/2021/12/01/61a770edfdddffdb8e8b4595.html

- text56.txt(462 palabras): La OMS califica de 'preocupante' la variante ómicron: ¿es tan fiera como la pintan?
 - https://www.elmundo.es/ciencia-y-salud/salud/2021/11/27/61a14a37fc6c83d3438b45ba.html

- text57.txt(413 palabras): La UE cierra sus puertas a los viajeros del Sur de África - https://www.elmundo.es/ciencia-y-salud/salud/2021/11/26/61a10218fc6c8338698b458c.html

- text58.txt(500 palabras): La OMS nombra Ómicron a la nueva variante del coronavirus y advierte de un posible "mayor riesgo de reinfección" - https://www.elmundo.es/ciencia-y-salud/salud/2021/11/26/61a12593e4d4d874228b45c1.html

- text59.txt(413 palabras): ¿Cómo es la nueva variante hallada en Sudáfrica? Mutaciones nunca vistas antes y una positividad del 1 al 30% en sólo tres semanas - https://www.elmundo.es/ciencia-y-salud/salud/2021/11/26/61a0944b21efa072088b45ac.html

- text60.txt(353 palabras): La incidencia alcanza los 171 puntos tras sumar casi 10.000 contagios en 24 horas - https://www.elmundo.es/ciencia-y-salud/salud/2021/11/26/61a0e0b5e4d4d81f068b45a5.html




# Política
1-30 noticias de El País
31-60 noticias de El Mundo


- text1.txt(232 palabras): El conservador Petr Fiala, nombrado primer ministro de la República Checa - https://elpais.com/internacional/2021-11-28/el-conservador-petr-fiala-nombrado-primer-ministro-de-la-republica-checa.html

- text2.txt(611 palabras): Los límites de la democracia - https://elpais.com/babelia/2021-11-27/los-limites-de-la-democracia.html

- text3.txt(436 palabras): María Jesús Montero niega que Bildu sea "socio prioritario" del Gobierno - https://elpais.com/espana/2021-11-26/maria-jesus-montero-niega-que-bildu-sea-socio-prioritario-del-gobierno.html

- text4.txt(464 palabras): La justicia europea descarta devolver la inmunidad parlamentaria a Puigdemont - https://elpais.com/espana/2021-11-26/la-justicia-europea-descarta-devolver-la-inmunidad-parlamentaria-a-puigdemont.html

- text5.txt(255 palabras): El PSOE pide que Mañueco dimita tras la imputación del PP salmantino - https://elpais.com/espana/2021-11-25/el-psoe-pide-que-manueco-dimita-tras-la-imputacion-del-pp-salmantino.html

- text6.txt(411 palabras): PSC, ERC, Junts y comunes aprueban el presupuesto de la Diputación de Barcelona - https://elpais.com/espana/catalunya/2021-11-25/psc-erc-junts-y-comunes-aprueban-el-presupuesto-de-la-diputacion-de-barcelona.html

- text7.txt(468 palabras): Ada Colau se abre a reformar La Rambla tras el 'sí' de ERC al presupuesto - https://elpais.com/espana/catalunya/2021-11-23/ada-colau-se-abre-a-reformar-la-rambla-tras-el-si-de-erc-al-presupuesto.html

- text8.txt(680 palabras): La estrategia de Casado no logra frenar la rebelión interna de una parte del PP - https://elpais.com/espana/2021-11-23/la-estrategia-de-casado-no-logra-frenar-la-rebelion-interna-de-una-parte-del-pp.html

- text9.txt(586 palabras): Ada Colau a Yolanda Díaz: "Nunca quisiste ser presidenta ni líder mundial, pero te ha tocado. España te necesita" - https://elpais.com/espana/catalunya/2021-11-21/colau-a-yolanda-diaz-nunca-quisiste-ser-presidenta-ni-lider-mundial-pero-te-ha-tocado-espana-te-necesita.html

- text10.txt(374 palabras): El PSOE canario reelige a Ángel Víctor Torres para un nuevo mandato - https://elpais.com/espana/2021-11-21/el-psoe-canario-reelige-a-angel-victor-torres-para-un-nuevo-mandato.html

- text11.txt(683 palabras): La hipótesis España vaciada - https://elpais.com/espana/2021-11-21/la-hipotesis-espana-vaciada.html

- text12.txt(515 palabras): Ingeniería política en la España vacía - https://elpais.com/opinion/2021-11-21/ingenieria-politica-en-la-espana-vacia.html

- text13.txt(397 palabras): Kamala Harris, presidenta de Estados Unidos durante un rato - https://elpais.com/internacional/2021-11-19/kamala-harris-se-convierte-en-la-primera-presidenta-en-funciones-de-estados-unidos.html

- text14.txt(508 palabras): Almeida afirma que Álvarez de Toledo "está en su derecho" de mantener el escaño - https://elpais.com/espana/2021-11-19/almeida-dice-que-alvarez-de-toledo-esta-en-su-derecho-de-mantener-el-escano.html

- text15.txt(555 palabras): López Obrador agita de nuevo la carrera presidencial a 2024: "Apoyaré a quien gane la encuesta de Morena" - https://elpais.com/mexico/2021-11-17/lopez-obrador-agita-de-nuevo-la-carrera-presidencial-a-2024-apoyare-a-quien-gane-la-encuesta-de-morena.html

- text16.txt(395 palabras): Carlos Mazón ante un posible pacto electoral con Ciudadanos: "Siempre que podamos unir, lo vamos a hacer" - https://elpais.com/espana/comunidad-valenciana/2021-11-16/carlos-mazon-ante-un-posible-pacto-electoral-con-ciudadanos-siempre-que-podamos-unir-lo-vamos-a-hacer.html

- text17.txt(414 palabras): Los independentistas piden que la ley de memoria retire el título al Rey - https://elpais.com/espana/2021-11-15/los-independentistas-piden-que-la-ley-de-memoria-retire-el-titulo-al-rey.html

- text18.txt(532 palabras): Un nuevo partido anticorrupción gana las elecciones en Bulgaria según los primeros resultados oficiales - https://elpais.com/internacional/2021-11-15/un-nuevo-partido-anticorrupcion-gana-las-elecciones-en-bulgaria-segun-los-primeros-resultados-oficiales.html

- text19.txt(608 palabras): Famosos que quieren hacer política - https://elpais.com/eps/2021-11-15/los-famosos-que-quieren-hacer-politica.html

- text20.txt(598 palabras): El precedente de la descentralización de organismos que puso a León en el mapa - https://elpais.com/espana/2021-11-15/el-precedente-que-puso-a-leon-en-el-mapa.html

- text21.txt(490 palabras): La ultraderecha entra en el Congreso de Argentina - https://elpais.com/internacional/2021-11-15/la-ultraderecha-entra-en-el-congreso-argentino.html

- text22.txt(467 palabras): La polémica frase de Pablo Casado sobre la energía solar: "A las ocho de la tarde no había posibilidad de que la solar emitiera porque era de noche" - https://elpais.com/espana/2021-11-14/la-polemica-frase-de-pablo-casado-sobre-la-energia-solar-a-las-ocho-de-la-tarde-no-habia-posibilidad-de-que-la-solar-emitiera-porque-era-de-noche.html

- text23.txt(464 palabras): Ximo Puig se lanza a la búsqueda de una mayoría con la intolerancia como único límite - https://elpais.com/espana/comunidad-valenciana/2021-11-14/ximo-puig-se-lanza-a-la-busqueda-de-una-mayoria-con-la-intolerancia-como-unico-limite.html

- text24.txt(526 palabras): Los socialistas valencianos viven el congreso más pacífico de los últimas dos décadas tras la salida de Ábalos - https://elpais.com/espana/2021-11-12/los-socialistas-valencianos-viven-el-congreso-mas-pacifico-de-los-ultimas-dos-decadas-tras-la-salida-de-abalos.html

- text25.txt(367 palabras): Casado reaparece tras dos semanas de perfil bajo por la crisis del PP de Madrid - https://elpais.com/espana/2021-11-12/casado-reaparece-tras-dos-semanas-de-perfil-bajo-por-la-crisis-del-pp-de-madrid.html

- text26.txt(546 palabras): Barones del PP proponen un acuerdo con Almeida de 'número dos' de Ayuso - https://elpais.com/espana/2021-11-11/barones-del-pp-proponen-un-acuerdo-con-almeida-de-numero-dos-de-ayuso.html

- text27.txt(453 palabras): Dirigentes de Podemos y de Esquerra Unida acudirán como "invitadas preferentes" al acto de Mónica Oltra con Yolanda Díaz - https://elpais.com/espana/comunidad-valenciana/2021-11-10/dirigentes-de-podemos-y-de-eu-acudiran-como-invitadas-preferentes-al-acto-de-monica-oltra-con-yolanda-diaz.html

- text28.txt(444 palabras): Alberto Rodríguez reclama al Supremo que anule su condena porque vulnera ocho derechos fundamentales - https://elpais.com/espana/2021-11-10/alberto-rodriguez-reclama-al-supremo-que-anule-su-condena-porque-vulnera-siete-derechos-fundamentales.html

- text29.txt(443 palabras): La boda que provocó una crisis en el Gobierno de López Obrador - https://elpais.com/mexico/2021-11-09/la-boda-que-provoco-una-crisis-en-el-gobierno-de-lopez-obrador.html

- text30.txt(500 palabras): El PSOE expedienta a un alcalde que se despeñó cuando conducía ebrio - https://elpais.com/espana/2021-11-05/el-psoe-expedienta-a-un-alcalde-que-se-despeno-cuando-conducia-ebrio.html

- text31.txt(398 palabras): Carrasco asume el PP-Castellón para renovar la capital - https://www.elmundo.es/comunidad-valenciana/castellon/2021/11/19/61980a88e4d4d84f6d8b45f0.html

- text32.txt(375 palabras): Alertan de la 'fuga' de sanitarios ante la excesiva burocracia en las bolsas de empleo de la Comunidad Valenciana - https://www.elmundo.es/comunidad-valenciana/castellon/2021/11/11/618d186ce4d4d82d3a8b45f7.html

- text33.txt(381 palabras): Una encuesta da un vuelco a la Generalitat: el PP gobernaría con su 'socio' Vox - https://www.elmundo.es/comunidad-valenciana/castellon/2021/11/05/618581dffdddff0e958b45b4.html

- text34.txt(426 palabras): Almassora no subirá los impuestos en 2022 pese a la anulación de la plusvalía y el aumento de los gastos - https://www.elmundo.es/comunidad-valenciana/castellon/2021/11/05/61856f97e4d4d8c4428b45c7.html

- text35.txt(479 palabras): El presupuesto del Consell para 2022 mete a Castellón en el furgón de cola - https://www.elmundo.es/comunidad-valenciana/castellon/2021/11/05/61843955e4d4d86c668b458b.html

- text36.txt(540 palabras): Ni el homenaje a los represaliados del franquismo une al tripartito - https://www.elmundo.es/comunidad-valenciana/castellon/2021/11/02/61805b7be4d4d8932b8b45b5.html

- text37.txt(455 palabras): Vila-real aprueba 170.000 euros para la expropiación del suelo de la nueva depuradora - https://www.elmundo.es/comunidad-valenciana/castellon/2021/10/27/6179216afdddff07718b4595.html

- text38.txt(329 palabras): El Parlament debatirá este martes sobre la posibilidad de eliminar la existencia de un juicio por corrupción como causa de suspensión de un diputado - https://www.elmundo.es/cataluna/2021/10/26/6177a3c021efa0e11c8b459f.html

- text39.txt(102 palabras): El PSC liderará un gobierno multipartito en Badalona tras la moción a Albiol - https://www.elmundo.es/cataluna/2021/10/25/61771468fc6c83e1718b45a6.html

- text40.txt(389 palabras): PSOE y PP acuerdan que Ángel Gabilondo sea el nuevo Defensor del Pueblo y Teresa Jiménez-Becerril, su 'número dos' - https://www.elmundo.es/espana/2021/10/21/61715ce2e4d4d8fe0e8b45ce.html

- text41.txt(166 palabras): Podemos ve en la monarquía una institución "corrupta, obsoleta y anacrónica" - https://www.elmundo.es/espana/2021/10/11/61643253fdddffd5538b45df.html

- text42.txt(536 palabras): La Vilavella sube el sueldo a la alcaldesa por un 'fallo' en el IRPF que Hacienda le ha "penalizado" - https://www.elmundo.es/comunidad-valenciana/castellon/2021/10/05/615c0a32fc6c83bf038b45a3.html

- text43.txt(383 palabras): El PNV pretende convertir el País Vasco en una "nación europea" en 2050 y llevar al Pueblo Vasco a "la libertad" - https://www.elmundo.es/pais-vasco/2021/11/28/61a369f6fc6c83e9178b45c9.html

- text44.txt(553 palabras): Los fiscales y el PP exigen la dimisión de Dolores Delgado por ser "incompatible con la imparcialidad" - https://www.elmundo.es/espana/2021/11/27/61a2a470fdddff9a128b459f.html

- text45.txt(512 palabras): Esperanza Aguirre, Francisco Vázquez y Ortega Lara arropan en su estreno a NEOS, la plataforma de Mayor Oreja - https://www.elmundo.es/espana/2021/11/26/61a13f23fc6c83e2618b456e.html

- text46.txt(569 palabras): El 'caso Primarias' del PP de Salamanca incentiva el adelanto electoral en Castilla y León - https://www.elmundo.es/espana/2021/11/26/619fd587fdddff00438b4593.html

- text47.txt(307 palabras): El Supremo confirma la prisión para el juez Alba por conspirar contra Victoria Rosell - https://www.elmundo.es/espana/2021/11/25/619f7d8521efa0cf328b458d.html

- text48.txt(520 palabras): Siete de cada diez casos de violencia sexual revisados por el Supremo en 2020 tenían como víctimas a niños - https://www.elmundo.es/espana/2021/11/25/619f7a8121efa078168b45db.html

- text49.txt(282 palabras): La alcaldesa de Béjar en Salamanca dimite tras su incidente con la Policía Local - https://diariodecastillayleon.elmundo.es/articulo/salamanca/alcaldesa-bejar-salamanca-dimite/20211125102909036641.html

- text50.txt(618 palabras): La 'vía valenciana' es el modelo que más gusta en Hacienda para reformar la financiación autonómica - https://www.elmundo.es/espana/2021/11/25/619e7b1ffdddfff0938b45f9.html

- text51.txt(376 palabras): El PSOE protege a Marlaska y descarga en el operativo policial de Cádiz la decisión de sacar la tanqueta - https://www.elmundo.es/espana/2021/11/24/619e4cc621efa0767a8b4600.html

- text52.txt(457 palabras): El conservador Petr Fiala, nombrado primer ministro de la República Checa - https://www.elmundo.es/internacional/2021/11/28/61a3ad09fc6c83180c8b45b9.html

- text53.txt(295 palabras): Un avión de Frontex reforzará el control migratorio en el Canal de la Mancha - https://www.elmundo.es/internacional/2021/11/28/61a3beaafdddff32838b45a0.html

- text54.txt(348 palabras): Boris Johnson vuelve a amenazar con romper el protocolo de Irlanda del Norte - https://www.elmundo.es/internacional/2021/11/25/619ee56ae4d4d82f6c8b45d0.html

- text55.txt(379 palabras): Francia e Italia firman un nuevo tratado de cooperación - https://www.elmundo.es/internacional/2021/11/26/61a0b62cfdddffe2b08b45b1.html

- text56.txt(597 palabras): El PSOE demanda cambios en los presupuestos de la Junta para 2022 por valor de 767 millones de euros - https://www.elmundo.es/andalucia/2021/11/15/6192b19921efa0a4618b45a0.html

- text57.txt(269 palabras): El PP critica la "hipocresía" de Vox al hablar de las necesidades de Burgos sin presentar enmiendas a los Presupuestos - https://diariodecastillayleon.elmundo.es/articulo/politica/pp-critica-hipocresia-vox-hablar-necesidades-burgos-presentar-enmiendas-presupuestos/20211121191035036327.html

- text58.txt(484 palabras): El PSOE presenta un millar de enmiendas a los Presupuestos para 2022 - https://diariodecastillayleon.elmundo.es/articulo/politica/psoe-presenta-millar-enmiendas-presupuestos-2022/20211119183613036251.html

- text59.txt(487 palabras): PP y Cs presentan 23 enmiendas a sus propios presupuestos para 2022 - https://diariodecastillayleon.elmundo.es/articulo/politica/pp-y-cs-presentan/20211119183127036249.html

- text60.txt(173 palabras): Marta Sanz (Cs): "Viva España, viva el rey, viva el orden y la ley" - https://diariodecastillayleon.elmundo.es/articulo/politica/marta-sanz-cs-viva-espana-viva-rey-viva-orden-ley/20210414160240025665.html


# Otra categoría

- text1.txt( palabras): 

- text2.txt( palabras):

- text3.txt( palabras): 

- text4.txt( palabras): 

- text5.txt( palabras): 

- text6.txt( palabras): 

- text7.txt( palabras): 

- text8.txt( palabras): 

- text9.txt( palabras): 

- text10.txt( palabras): 

- text11.txt( palabras): 

- text12.txt( palabras): 

- text13.txt( palabras): 

- text14.txt( palabras): 

- text15.txt( palabras): 

- text16.txt( palabras): 

- text17.txt( palabras): 

- text18.txt( palabras): 

- text19.txt( palabras): 

- text20.txt( palabras): 

- text21.txt( palabras): 

- text22.txt( palabras): 

- text23.txt( palabras): 

- text24.txt( palabras): 

- text25.txt( palabras): 

- text26.txt( palabras): 

- text27.txt( palabras): 

- text28.txt( palabras): 

- text29.txt( palabras): 

- text30.txt( palabras): 

- text31.txt( palabras): 

- text32.txt( palabras): 

- text33.txt( palabras): 

- text34.txt( palabras): 

- text35.txt( palabras): 

- text36.txt( palabras): 

- text37.txt( palabras): 

- text38.txt( palabras): 

- text39.txt( palabras): 

- text40.txt( palabras): 

- text41.txt( palabras): 

- text42.txt( palabras): 

- text43.txt( palabras): 

- text44.txt( palabras): 

- text45.txt( palabras): 

- text46.txt( palabras): 

- text47.txt( palabras): 

- text48.txt( palabras): 

- text49.txt( palabras): 

- text50.txt( palabras): 

- text51.txt( palabras): 

- text52.txt( palabras): 

- text53.txt( palabras): 

- text54.txt( palabras): 

- text55.txt( palabras): 

- text56.txt( palabras): 

- text57.txt( palabras): 

- text58.txt( palabras): 

- text59.txt( palabras): 

- text60.txt( palabras): 
